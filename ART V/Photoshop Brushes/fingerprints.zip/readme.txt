THIS FILE WAS DOWNLOADED FROM http://chain.deviantart.com/

Contents of zip-archive:
���������������������
fingerprints.abr  -  Photoshop brushes
readme.txt        -  (this file)

You are free to use theese brushes for any purpose you'd like, but if you make something cool with them, please tell me, and I might link the picture on the page where you downloaded the brushes. You may also distribute theese brushes (for free) freely as long as you keep the file intact and include this file.

ENJOY!

� Jonas M. Rogne, alias Chain
chain__@hotmail.com
http://chain.cjb.net/
http://chain.deviantart.com/gallery/